#!/bin/bash
# Script de instalación para el servidor de producción

# Colores para mensajes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}Iniciando instalación de bibliotecas para el sistema tarificador...\033[0m"

# Activar entorno virtual
if [ -d "/opt/tarificador/venv" ]; then
  echo -e "${GREEN}Activando entorno virtual...\033[0m"
  source /opt/tarificador/venv/bin/activate
else
  echo -e "${RED}⚠️ Entorno virtual no encontrado en /opt/tarificador/venv\033[0m"
  exit 1
fi

# Instalar bibliotecas desde wheels
echo -e "${GREEN}Instalando bibliotecas desde archivos wheel...\033[0m"
pip install --no-index --find-links=./wheels -r clean_requirements.txt

# Verificar instalación
echo -e "${GREEN}Verificando instalación:\033[0m"
failed_imports=0
success_imports=0

for lib in $(cat clean_requirements.txt); do
  # Normalizar nombre de la biblioteca para importación
  import_name=$(echo $lib | tr '-' '_' | tr '[:upper:]' '[:lower:]')
  
  # Intentar importar la biblioteca
  if python -c "import $import_name" 2>/dev/null; then
    echo -e "${GREEN}✅ $lib importado correctamente\033[0m"
    success_imports=$((success_imports + 1))
  else
    # Algunos paquetes tienen nombres diferentes para importar
    case $lib in
      "psycopg2-binary")
        if python -c "import psycopg2" 2>/dev/null; then
          echo -e "${GREEN}✅ $lib importado correctamente como psycopg2\033[0m"
          success_imports=$((success_imports + 1))
        else
          echo -e "${RED}❌ $lib no se pudo importar\033[0m"
          failed_imports=$((failed_imports + 1))
        fi
        ;;
      "python-multipart")
        if python -c "import multipart" 2>/dev/null; then
          echo -e "${GREEN}✅ $lib importado correctamente como multipart\033[0m"
          success_imports=$((success_imports + 1))
        else
          echo -e "${RED}❌ $lib no se pudo importar\033[0m"
          failed_imports=$((failed_imports + 1))
        fi
        ;;
      *)
        echo -e "${RED}❌ $lib no se pudo importar\033[0m"
        failed_imports=$((failed_imports + 1))
        ;;
    esac
  fi
done

echo -e "${GREEN}Instalación completada.\033[0m"
echo -e "${GREEN}Bibliotecas instaladas correctamente: $success_imports\033[0m"
if [ $failed_imports -gt 0 ]; then
  echo -e "${RED}Bibliotecas con problemas: $failed_imports\033[0m"
  echo -e "${YELLOW}Nota: Algunos paquetes pueden ser subdependencias y no necesitan ser importados directamente.\033[0m"
fi
